#!/bin/bash
# Stop the script if any command fails
set -e

# 1. Check if variables are set
if [ -z "$QUALITY_CHECK_RESULTS_TO_VERSIO_SERVER" ]; then
    echo "Missing: QUALITY_CHECK_RESULTS_TO_VERSIO_SERVER"
    exit 1
fi

if [ -z "$QUALITY_CHECK_RESULTS_TO_VERSIO_ENVIRONMENT" ]; then
    echo "Missing: QUALITY_CHECK_RESULTS_TO_VERSIO_ENVIRONMENT"
    exit 1
fi

if [ -z "$EOL_VUL_QUALITY_CHECKS_API_TOKEN" ]; then
    echo "Missing: EOL_VUL_QUALITY_CHECKS_API_TOKEN"
    exit 1
fi

# 2. Get the folder where this script is located
parent_path=$( cd "$(dirname "${BASH_SOURCE[0]}")" ; pwd -P )

# 3. Run the Node.js application
node "$parent_path/main.js"