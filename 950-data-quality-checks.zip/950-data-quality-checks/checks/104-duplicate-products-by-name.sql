SELECT
'Duplicated product and vendor names in the products table' AS displayName,

"
## Problem
The database contains products and vendor with the same name, which suggests potential duplicates. This check specifically targets product name duplication, while ignoring two exceptions:
* Pairs of products where either vendor is 'Red Hat'.
* Products with the name 'java'.

## Impact
Duplicate products can lead to unnecessary product listings and counts and confusion in reporting.

## Solution
1. Execute the following SQL statement to find the violating product pairs:
```sql
SELECT
    p1.id,
    p1.product,
    p1.vendor,
    p2.id AS secondProductId,
    p2.product AS secondProductName,
    p2.vendor AS secondProductVendor
FROM
    products AS p1
INNER JOIN
    products AS p2
    ON p1.id < p2.id
    AND LOWER(p1.product) = LOWER(p2.product)
    AND LOWER(p1.vendor) = LOWER(p2.vendor) -- Matches the vendor case-insensitively
WHERE
    'Red Hat' NOT IN (p1.vendor, p2.vendor)
    AND LOWER(p1.product) NOT IN ('java');

```
2. For the identified pairs, determine if they are true duplicates that should be merged, or if they require a unique naming convention.

"
AS description,
    p1.id,
    1 AS violatioin,
    p1.product,
    p1.vendor,
    p2.id AS secondProductId,
    p2.product AS secondProductName,
    p2.vendor AS secondProductVendor
FROM
    products AS p1
INNER JOIN
    products AS p2
    ON p1.id < p2.id
    AND LOWER(p1.product) = LOWER(p2.product)
    AND LOWER(p1.vendor) = LOWER(p2.vendor)
WHERE
    'Red Hat' NOT IN (p1.vendor, p2.vendor)
    AND LOWER(p1.product) NOT IN ('java');