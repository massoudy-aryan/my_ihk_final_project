SELECT

    -- A short name describing what this check is about
    'Invalid JSON fields in table products' AS displayName,

    -- A more detailed explanation of what this rule checks
"
## Problem
A product includes several table columns that contain JSON. At least one attribute contains an invalid JSON format.
## Impact
Versio.io cannot correctly assess the product, and this can lead to issues with the EOL & VUL-Assessment processing.
## Solution
1. Execute the following SQL statement to find the erroneous products:
```
SELECT 
    *
FROM 
    products AS p
WHERE 
    JSON_VALID(p.cveMapping) = 0
    OR JSON_VALID(p.statistics) = 0
    OR JSON_VALID(p.metadata) = 0
    OR JSON_VALID(p.supportedStrategies) = 0
    OR JSON_VALID(p.recommendedStrategies) = 0
    OR JSON_VALID(p.releases) = 0
    OR JSON_VALID(p.technologyDetection) = 0
    OR JSON_VALID(p.versionDetection) = 0
    OR JSON_VALID(p.serviceDetection) = 0
    OR JSON_VALID(p.fileDetection) = 0;
```
2. Correct the attribute so that it is valid JSON.
"

AS description
,

    9 AS severity,
    1 AS violation,
    p.id AS productId,
    p.vendor,
    p.product,
    CONCAT (
        'https://live.versio.io/products?e=e2wqx5t27q&vendor=',
        p.vendor,
        '&product=',
        p.product
    ) AS productLink
FROM
    productLifecycleSecurity.products AS p
WHERE
    JSON_VALID (p.cveMapping) = 0
    OR JSON_VALID (p.statistics) = 0
    OR JSON_VALID (p.metadata) = 0
    OR JSON_VALID (p.supportedStrategies) = 0
    OR JSON_VALID (p.recommendedStrategies) = 0
    OR JSON_VALID (p.releases) = 0
    OR JSON_VALID (p.technologyDetection) = 0
    OR JSON_VALID (p.versionDetection) = 0
    OR JSON_VALID (p.serviceDetection) = 0
    OR JSON_VALID (p.fileDetection) = 0