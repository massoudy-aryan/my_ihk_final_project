SELECT

    -- A short name describing what this check is about
    'Format for a product release is not standardised' AS displayName,

    -- A more detailed explanation of what this rule checks
"
## Problem
A product''s releases array contains multiple entries (releases) where the **majorVersion** attribute uses different formatting conventions (e.g., some are ''1.0'' (two parts), others are ''1.0.0'' (three parts)).
## Impact
Inconsistent major version formatting can cause issues with version sorting, comparison, and automated processing for EOL & VUL-Assessment, leading to inaccurate or incomplete lifecycle reporting.
## Solution
1. Execute the following SQL statement to find the erroneous products:
```
SELECT
    p.id AS product_id,
    p.product,
    p.vendor,    
    GROUP_CONCAT(DISTINCT LENGTH(r.majorVersion) - LENGTH(REPLACE(r.majorVersion, '.', ''))) AS number_of_version_parts
FROM
    products p
JOIN JSON_TABLE(
    p.releases,
    '$[*]' COLUMNS (
        majorVersion VARCHAR(500) PATH '$.majorVersion'
    )
) AS r
GROUP BY
    p.id
HAVING
    number_of_version_parts LIKE '%,%'
ORDER BY
    p.id;
```
2. Manually review the `releases` JSON data for the identified products and normalize the `majorVersion` format across all releases for that product (e.g., ensure all are either two-part or three-part versions).
"

AS description
,

    -- Severity for the check from 1 (minimum) to 10 (maximum)
    7 AS severity, -- Assigned an assumed severity level
    p.id AS product_id,
    p.product,
    p.vendor,    
    GROUP_CONCAT(DISTINCT LENGTH(r.majorVersion) - LENGTH(REPLACE(r.majorVersion, '.', ''))) AS number_of_version_parts
FROM
    products p
JOIN JSON_TABLE(
    p.releases,
    '$[*]' COLUMNS (
        majorVersion VARCHAR(500) PATH '$.majorVersion'
    )
) AS r
GROUP BY
    p.id
HAVING
    number_of_version_parts LIKE '%,%'
ORDER BY
    p.id;