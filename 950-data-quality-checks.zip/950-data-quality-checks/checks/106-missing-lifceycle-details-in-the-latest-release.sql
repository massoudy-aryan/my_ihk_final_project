SELECT
	 "Missing maintenance and maintenance-extended details in the latest release" AS displayName,
	 "
*Category:* **Data quality**
## Problem
The `releases` JSON array in a product record contains inconsistent data regarding key lifecycle dates (Maintenance, Maintenance-Extended, Support, or Support-Extended). Specifically, one of these dates is present in **at least one** release object within the array, but is **missing from the first release object** (`$[0]`). This often indicates an error where the most important (e.g., latest or most relevant) release is incomplete, or the releases are not correctly ordered.
## Impact
Versio.io processes often rely on the first release object in the array (`$[0]`) to quickly retrieve crucial lifecycle dates for EOL and VUL-Assessment. If a date is missing from this primary object while present in others, the product may be incorrectly assessed, leading to delayed or inaccurate end-of-life and vulnerability reporting.
## Solution
1. Execute the following SQL statement to find the erroneous products:
```sql
SELECT
    id,
    JSON_CONTAINS_PATH(releases, 'one', '$[*].maintenance.start') AS haveSomeMaintenance,
    JSON_CONTAINS_PATH(releases, 'one', '$[0].maintenance.start') AS haveLastMaintenance,

    JSON_CONTAINS_PATH(releases, 'one', '$[*].maintenance-extended.start') AS haveSomeMaintenanceExtended,
    JSON_CONTAINS_PATH(releases, 'one', '$[0].maintenance-extended.start') AS haveLastMaintenanceExtended,

    JSON_CONTAINS_PATH(releases, 'one', '$[*].support.start') AS haveSomeSupport,
    JSON_CONTAINS_PATH(releases, 'one', '$[0].support.start') AS haveLastSupport,

    JSON_CONTAINS_PATH(releases, 'one', '$[*].support-extended.start') AS haveSomeSupportExtended,
    JSON_CONTAINS_PATH(releases, 'one', '$[0].support-extended.start') AS haveLastSupportExtended
FROM
    products
HAVING
    haveSomeMaintenance != haveLastMaintenance
    OR haveSomeMaintenanceExtended != haveLastMaintenanceExtended
    OR haveSomeSupport != haveLastSupport
    OR haveSomeSupportExtended != haveLastSupportExtended;
2. Find and record the Maintenance or MaintenanceExtended details for the latest release.

```
" AS description,

    id AS productId,
    vendor,
    product,
    1 AS violation,
    JSON_CONTAINS_PATH(releases, 'one', '$[*].maintenance.start') AS haveSomeMaintenance,
    JSON_CONTAINS_PATH(releases, 'one', '$[0].maintenance.start') AS haveLastMaintenance,

    JSON_CONTAINS_PATH(releases, 'one', '$[*].maintenance-extended.start') AS haveSomeMaintenanceExtended,
    JSON_CONTAINS_PATH(releases, 'one', '$[0].maintenance-extended.start') AS haveLastMaintenanceExtended,

    JSON_CONTAINS_PATH(releases, 'one', '$[*].support.start') AS haveSomeSupport,
    JSON_CONTAINS_PATH(releases, 'one', '$[0].support.start') AS haveLastSupport,

    JSON_CONTAINS_PATH(releases, 'one', '$[*].support-extended.start') AS haveSomeSupportExtended,
    JSON_CONTAINS_PATH(releases, 'one', '$[0].support-extended.start') AS haveLastSupportExtended
FROM
    products
HAVING
    haveSomeMaintenance != haveLastMaintenance
    OR haveSomeMaintenanceExtended != haveLastMaintenanceExtended
    OR haveSomeSupport != haveLastSupport
    OR haveSomeSupportExtended != haveLastSupportExtended;