SELECT
    CONCAT(p.product, ' - Wrong order of release lifecycle dates in releases column') AS displayName,
    "
## Problem
The product's release and maintenance attributes (like 'maintenance-extended', or 'maintenance' or 'support') contain a mistake where a start date is equal to or occurs *after* its corresponding end date. The start date of these attributes should be  *before* the end date.
## Impact
This leads to incorrect calculations for End-of-Life (EOL) processing, reporting, and visualization in versio.io, as the duration of the support period cannot be accurately determined or is reported as a negative value.
## Solution
1. Execute the following SQL statement to find the products with erroneous release entries:

```sql
SELECT
    p.id,
    jt.majorVersion
FROM
    products AS p,
    JSON_TABLE(
        p.releases,
        '$[*]'
        COLUMNS(
            majorVersion VARCHAR(100) PATH '$.majorVersion',
            releaseStart BIGINT(13) PATH '$.release.start',
            versionDeliveryStart BIGINT(13) PATH '$.versionDelivery.start',
            versionDeliveryEnd BIGINT(13) PATH '$.versionDelivery.end',
            maintenanceStart BIGINT(13) PATH '$.maintenance.start',
            maintenanceEnd BIGINT(13) PATH '$.maintenance.end',
            maintenanceExtendedStart BIGINT(13) PATH '$.maintenance-extended.start',
            maintenanceExtendedEnd BIGINT(13) PATH '$.maintenance-extended.end',
            supportStart BIGINT(13) PATH '$.support.start',
            supportEnd BIGINT(13) PATH '$.support.end',
            supportExtendedStart BIGINT(13) PATH '$.support-extended.start',
            supportExtendedEnd BIGINT(13) PATH '$.support-extended.end'
        )
    ) AS jt
WHERE
    jt.maintenanceStart >= jt.maintenanceEnd
    OR jt.maintenanceExtendedStart >= jt.maintenanceExtendedEnd
    OR jt.supportStart >= jt.supportEnd
    OR jt.supportExtendedStart >= jt.supportExtendedEnd;
```
2. Correct the order of dates for maintenanceStart and maintenanceEnd or the order of dates for maintenanceExtendedStart and its end.
" AS description,

    4 AS severity,
    1 AS violation,
    p.id AS productId,
    p.vendor,
    p.product,
    jt.majorVersion AS majorVersion,
    CONCAT ('https://live.versio.io/products?e=e2wqx5t27q&vendor=', p.vendor, '&product=', p.product) AS productLink
FROM
    products AS p,
    JSON_TABLE(p.releases, '$[*]'
        COLUMNS(
            majorVersion VARCHAR(100) PATH '$.majorVersion',
            maintenanceStart BIGINT(13) PATH '$.maintenance.start',
            maintenanceEnd BIGINT(13) PATH '$.maintenance.end',
            maintenanceExtendedStart BIGINT(13) PATH '$.maintenance-extended.start',
            maintenanceExtendedEnd BIGINT(13) PATH '$.maintenance-extended.end',
            supportStart BIGINT(13) PATH '$.support.start',
            supportEnd BIGINT(13) PATH '$.support.end',
            supportExtendedStart BIGINT(13) PATH '$.support-extended.start',
            supportExtendedEnd BIGINT(13) PATH '$.support-extended.end'
        )
    ) AS jt
WHERE
    -- Ignore Red Hat
    p.vendor != 'Red Hat'
    AND (
        -- Check for logical errors where a start date is >= its corresponding end date
        (jt.maintenanceStart IS NOT NULL AND jt.maintenanceStart >= jt.maintenanceEnd) OR
        (jt.maintenanceExtendedStart IS NOT NULL AND jt.maintenanceExtendedStart >= jt.maintenanceExtendedEnd) OR
        (jt.supportStart IS NOT NULL AND jt.supportStart >= jt.supportEnd) OR
        (jt.supportExtendedStart IS NOT NULL AND jt.supportExtendedStart >= jt.supportExtendedEnd)
    )
GROUP BY
    p.id, p.vendor, p.product, jt.majorVersion;