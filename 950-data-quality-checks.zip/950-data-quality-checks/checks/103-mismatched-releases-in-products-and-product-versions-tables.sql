SELECT
    'Mismatched number of releases in product and productVersions tables' AS displayName,
"
## Problem
The number of releases recorded in the products.releases column are not equal to the number of unique releases recorded in the productVersions.calcRelease column.
## Impact
Versio.io cannot correctly calcuate the number of majorVersion in products table. Meaning that releases are not recorded exactly as our productVersions table shows.
## Solution
1. Execute the following SQL statement to find the erroneous products:
```
SELECT
    id,
    JSON_LENGTH(releases) AS productReleaseCount,
    (
        SELECT
            COUNT(DISTINCT calcRelease)
        FROM
            productVersions
        WHERE
            refIdProduct = id
    ) AS versionReleaseCount
FROM
    products
HAVING
    versionReleaseCount != productReleaseCount;
```
2. Check which releases are missing or are recorded extra in the releases column of products TABLE.

" AS description,
    id AS productId,
    product,
    vendor,
    JSON_LENGTH (releases) AS productReleaseCount,
    1 as violation,
    (
        SELECT
            COUNT(DISTINCT calcRelease)
        FROM
            productVersions
        WHERE
            refIdProduct = products.id
    ) AS versionReleaseCount
FROM
    products
WHERE
    id < 200000
HAVING
    versionReleaseCount != productReleaseCount;