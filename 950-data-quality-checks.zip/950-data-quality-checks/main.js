import connectionPool from '../../utils/database.js';
import axios from 'axios';
import { readFile, readdir } from 'fs/promises';
import { join } from 'path';
import { fileURLToPath } from 'url';

const SQL_CHECKS_DIR = fileURLToPath(new URL('./checks', import.meta.url));

async function runQualityChecks() {
    try {
        // 1. Get the list of SQL check files
        const files = await readdir(SQL_CHECKS_DIR);
        const sqlFiles = files.filter(f => f.endsWith('.sql'));

        console.error(`Anzahl an Prüfdateien gefunden: ` + sqlFiles.length);

        for (const fileName of sqlFiles) {
            const sqlCheckFileName = fileName.replace(/\.sql$/i, '');
            const filePath = join(SQL_CHECKS_DIR, fileName);

            // 2. Read and run the SQL query from the file
            const sql = await readFile(filePath, 'utf8');
            const [rows] = await connectionPool.query(sql);

            console.error(`Verarbeite ${sqlCheckFileName}: ${rows.length} Zeilen gefunden.`);

            // 3. Loop through results
            for (let row of rows) {
                // Only process if it's a violation
                if (row.violation === 1) {
                    try {

                        let eventJSON = [{
                            "id": row.productId ? row.productId.toString() : sqlCheckFileName.toString().slice(0, 36),
                            "utc": Date.now(),
                            "sourceType": "PLV",
                            "trigger": (row.productId || row.displayName) + " | " + (row.vendor || '') + " | " + (row.product || ''),
                            "externalIdLink": row.productLink || `https://live.versio.io/products?product=${encodeURIComponent(row.product || '')}&vendor=${encodeURIComponent(row.vendor || '')}`,
                            "externalIdName": (row.vendor || '') + " " + (row.product || ''),
                            "severity": Number(row.severity) || 3,
                            "classification": sqlCheckFileName,
                            "message": row.description || "Data quality violation detected."
                        }];

                        // 4. Construct URL from environment variables
                        const server = process.env.QUALITY_CHECK_RESULTS_TO_VERSIO_SERVER;
                        const env = process.env.QUALITY_CHECK_RESULTS_TO_VERSIO_ENVIRONMENT;
                        const token = process.env.EOL_VUL_QUALITY_CHECKS_API_TOKEN;
                        const url = `https://${server}/api-versio.eventProcessing/1.0/environments/${env}/events?apiToken=${token}`;

                        console.log(`------------------------------------------------------`);
                        console.log(`Versuche zu senden (ID: ${sqlCheckFileName})`);
                        
                        const response = await axios.post(url, eventJSON);
                        
                        console.log(`Status: ${response.status} - Erfolgreich gesendet!`);
                        console.log(`------------------------------------------------------`);

                    } catch (err) {
                        const errorData = err.response ? JSON.stringify(err.response.data) : err.message;
                        console.error(`Fehler beim Senden der Zeile: ${errorData}`);
                    }
                }
            }
        }
        console.error(`Prüfung beendet`);
    } catch (err) {
        console.error(`Allgemeiner Fehler: ${err.message}`);
    } finally {
        // Close database connection
        await connectionPool.end();
    }
}

// Execute script
runQualityChecks().then(() => process.exit(0)).catch(err => {
    console.error(`Kritischer Fehler: ${err.message}`);
    process.exit(1);
});