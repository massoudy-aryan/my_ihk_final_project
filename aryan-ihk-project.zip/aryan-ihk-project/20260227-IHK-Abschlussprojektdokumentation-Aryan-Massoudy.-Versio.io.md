# Entwicklung eines Qualitätsprüfungssystems für den Versio.io Produktlebenszyklus und Schwachstellen-Datenbankcontent
*Abschlussdokumentation Aryan Massoudy IHK-Projekt*


Betreuer von Seiten der Ausbildungsstätte: Matthias Scholze (QMETHODS/Versio.io)

<div style="page-break-after: always;"></div>

## Inhaltsverzeichnis

1. [Einleitung](#1-einleitung)  
   1.1. [Projektbeschreibung](#11-projektbeschreibung)  
   1.2. [Projektziel](#12-projektziel)  
   1.3. [Projektmotivation](#13-projektmotivation)  
   1.4. [Projektbeteiligte](#14-projektbeteiligte)  
   1.5. [Projektabgrenzen](#15-projektabgrenzen)  
   1.6. [Anwendungsfälle](#16-anwendungsfälle)  


2. [Planung](#3-planung)  

   2.1. [Aktivitäts- und Aufwandsplanung](#35-erstellung-des-pflichtenhefts)  
   2.2. [Ressourcenplanung](#35-erstellung-des-pflichtenhefts)  
   2.3. [Risikoanalyse](#35-erstellung-des-pflichtenhefts)  


3. [Konzeption](#2-konzeption)  

   3.5. [Erstellung des Pflichtenhefts](#35-erstellung-des-pflichtenhefts)  
   3.1. [Entwurf der UML-Diagramme (Aktivitäts- und Use-Case-Diagramm)](#31-entwurf-der-uml-diagramme-aktivitäts--und-use-case-diagramm)  
   3.2. [Entwurf der Datenbank-Anbindung](#32-entwurf-der-datenbank-anbindung)  
   3.3. [Ausarbeitung der Versio.io API Rate-Limiting](#33-ausarbeitung-der-versioio-api-rate-limiting)  
   3.4. [Entwurf API-Integration & Error-Handling](#34-entwurf-api-integration--error-handling)  


   2.1. [Soll/Ist- und Wirtschaftlichkeitsanalyse (Ink. Amortisationsdauer)](#21-sollist--und-wirtschaftlichkeitsanalyse-ink-amortisationsdauer)  
   2.2. [Analyse der Pipeline-Struktur und Architektur](#22-analyse-der-pipeline-struktur-und-architektur)  
   2.3. [Analyse der API-Schnittstelle und Anforderungen](#23-analyse-der-api-schnittstelle-und-anforderungen)  
   2.4. [Festlegung des standardisierten SQL-Formats](#24-festlegung-des-standardisierten-sql-formats)  
   2.5. [Vorbereitung des Projekt-Lastenhefts](#25-vorbereitung-des-projekt-lastenhefts)  

    x.y [Lösungsalternativen]

4. [Durchführung](#4-durchführung)  
   4.1. [Erstellung der Struktur in der bestehenden Pipeline](#41-erstellung-der-struktur-in-der-bestehenden-pipeline)  
   4.2. [Implementierung Datenbank-Anbindung](#42-implementierung-datenbank-anbindung)  
   4.3. [Entwicklung des SQL-Datei-Scanners](#43-entwicklung-des-sql-datei-scanners)  
   4.4. [Realisierung optimierter Prozessor für API-Calls](#44-realisierung-optimierter-prozessor-für-api-calls)  
   4.5. [Sicherstellung des Rate-Limiting-Mechanism](#45-sicherstellung-des-rate-limiting-mechanism)  
   4.6. [Implementierung der Logik zur Ergebnisformatierung](#46-implementierung-der-logik-zur-ergebnisformatierung)  
   4.7. [Entwicklung der API-Schnittstelle (PUT/POST-Requests)](#47-entwicklung-der-api-schnittstelle-putpost-requests)  
   4.8. [Implementierung eines robusten Fehlerhandlings (Try-Catch)](#48-implementierung-eines-robusten-fehlerhandlings-try-catch)  
   4.9. [Integration von Logging](#49-integration-von-logging)  
   4.10. [Erstellung des Shell-Skript-Wrappers (main.sh)](#410-erstellung-des-shell-skript-wrappers-mainsh)  
   4.11. [Konfiguration der Umgebungsvariablen & Tokens](#411-konfiguration-der-umgebungsvariablen--tokens)  
   4.12. [Code-Refactoring und Optimierung](#412-code-refactoring-und-optimierung)  
   4.13. [Erstellung von Beispiel-SQL-Queries](#413-erstellung-von-beispiel-sql-queries)  

5. [Qualitätsssicherung](#5-kontrolle--dokumentation)  
   5.1. [Code-Review durch das Entwicklungsteam](#51-code-review-durch-das-entwicklungsteam)  
   5.2. [Platzierung in die bestehende Pipeline](#52-platzierung-in-die-bestehende-pipeline)  
   5.3. [Erfolgskontrolle in der Entwicklungsumgebung und Whitebox Test](#53-erfolgskontrolle-in-der-entwicklungsumgebung-und-whitebox-test)  
   5.4. [Soll- Ist- Vergleich](#54-soll--ist--vergleich)  
   5.5. [Abnahme durch Projektverantwortliche](#55-abnahme-durch-projektverantwortliche)  

6. [Dokumentation](#5-kontrolle--dokumentation)  
   5.6. [Projektdokumentation](#56-erstellung-der-projektdokumentation-prozessorientiert)  
   5.7. [Entwicklerdokumentation](#57-erstellung-der-entwicklerdokumentation)  
   5.8. [Benutzerhandbuchs](#58-erstellung-des-benutzerhandbuchs)  

6. [Projektabschluss & Fazit](#6-fazit)  
   6.1. [Soll-Ist-Vergleich](#61-soll-ist-vergleich)  
   6.2. [Lessons Learned](#62-lessons-learned)  
   6.3. [Ausblick](#63-ausblick)  


A. [Anhang](#a-anhang)  
   A.0. [Literaturverzeichnis](#7-literaturverzeichnis)  
   A.1. [Lastenheft](#a1-lastenheft)  
   A.2. [Pflichtenheft](#a2-pflichtenheft)  
   A.3. [Verwendete Ressourcen](#a3-verwendete-ressourcen)  
   A.4. [Middleware](#a4-middleware)  
   A.5. [Der Grund für die Verwendung von Versio.io Events](#a5-der-grund-für-die-verwendung-von-versioio-events)  
   A.6. [Der Grund für die Verwendung von SQL-Datien](#a6-der-grund-für-die-verwendung-von-sql-datien)  
   A.7. [Fehlercodes und Statuscode-Meldungen](#a7-fehlercodes-und-statuscode-meldungen)  
   A.8. [Use-Case Diagramm](#a8-use-case-diagramm)  
   A.9. [Komponenten Diagramm](#a9-komponenten-diagramm)  


<div style="page-break-after: always;"></div>


# 1. Einleitung
## 1.1. Projektbeschreibung
Versio.io (ein Softwareprodukt der QMETHODS – Business & IT Consulting GmbH) ist eine Plattform, die die gesamte IT-Landschaft eines Unternehmens inventarisiert. Basierend auf dieser digitalen Nachbildung (Digital Twin) werden alle Änderungen erkannt und können im Hinblick auf IT-Governance und Sicherheit bewertet werden. Neben anderen Funktionen bietet Versio.io auch eine Bewertung des Lebenszyklus und der Sicherheit von Software- und Hardwareprodukten.

Im Backend wird eine Pipeline mit mehreren Schritten genutzt. Diese sorgt dafür, die benötigten Daten für unterstützte Software- und Hardwareprodukte aus verschiedenen Online-Quellen zu kollektieren, zu bearbeiten und in der Produktlebenszyklus- und Schwachstellen-Datenbank zu speichern. Nach der Speicherung in der DB, werden die Daten für das Frontend der Versio.io-Plattform bereitgestellt, welches von Kunden genutzt wird, um ihre eigene Software und Hardware auf Aktualität und Schwachstellen zu überprüfen.

Nun soll ich die Pipeline um einen weiteren Schritt erweitern, der SQL-Queries für verschiedene Qualitätskontrollen als Datei importiert, liest und gegen die Versio.io-Datenbankinhalte ausführt. Bei gefundenen Problemen werden diese mithilfe einer API an die Versio.io-Plattform gesendet. Dort werden sie intern von Versio.io QA-Mitarbeitern korrigiert und beim nächsten Durchlauf des Pipeline-Schritts als abgeschlossen gekennzeichnet.

## 1.2. Projektziel
Das primäre Projektziel ist die Implementierung eines weiteren Schrittes in der Backend-Pipeline zur Datenqualitätsprüfung. Dieser soll SQL-Dateien einlesen (welche von QA-Mitarbeitern bei Bedarf geschrieben werden, um Probleme zu erkennen), um eine automatisierte Überwachung und Berichterstattung zu gewährleisten.

Ein zentraler Bestandteil ist die direkte Anbindung an die Versio.io-Plattform via API, wodurch identifizierte Qualitätsprobleme ohne manuelles Eingreifen gemeldet werden. Die Robustheit soll durch Fehlerbehandlung für Datenbank- und Schnittstellenkonflikte sichergestellt werden. Durch die Umsetzung des Projekts soll die manuelle Datenqualitätsprüfung reduziert werden, was zu Zeit- und Kosteneinsparungen führen soll.

Für eine übersichtlichere und einfachere Darstellung des Soll-Konzepts dient das folgende Flussdiagramm:
Die Schritte 1, 2 und 3 sollen implementiert werden. Schritt 4 (Versio.io), der die Daten aus dem neuen Pipeline-Schritt empfängt und weiterverarbeitet, ist breit vorhanden.

## 1.3. Projektmotivation
[Content here]
## 1.4. Projektbeteiligte
[Content here]
## 1.5. Projektabgrenzen
[Content here]
## 1.6. Anwendungsfälle

<div style="page-break-after: always;"></div>


# 2. Planung
## 3.1. Entwurf der UML-Diagramme (Aktivitäts- und Use-Case-Diagramm)
```plantuml
@startuml
autonumber
skinparam Style strictuml

participant "runQualityChecks()" as Script
entity "File System" as FS
database "Database" as DB
participant "Versio API" as API

Script -> FS: readdir('./checks')
FS --> Script: sqlFiles[]

loop for each fileName in sqlFiles
    Script -> FS: readFile(filePath)
    FS --> Script: sqlQuery
    
    Script -> DB: query(sqlQuery)
    DB --> Script: rows[]
    
    loop for each row in rows
        alt row.violation === 1
            Script -> Script: Format eventJSON
            Script -> API: axios.post(url, eventJSON)
            API --> Script: 200 OK / Response
        else no violation
            note right: Skip row
        end
    end
end

Script -> DB: connectionPool.end()
@enduml
```
*Abbildung: skudfg asfg kaszdfg kasdzfg ksdhfgksdhf*


---
```plantuml

@startuml
start
:Read 'checks' directory;
:Filter for .sql files;

while (More files?) is (yes)
  :Read SQL content;
  :Execute Query on DB;
  
  while (More rows?) is (yes)
    if (row.violation == 1?) then (yes)
      :Construct eventJSON;
      partition "API Call" {
        if (POST to Versio API) then (success)
          :Log Success;
        else (failure/error)
          :Log Error;
        endif
      }
    else (no)
    endif
  endwhile
endwhile

:Close DB Connection;
stop
@enduml

```
---
1. Who (or what) is the Primary Actor?
Trigger: Does a human developer manually run this script, or is it triggered automatically by a Task Scheduler (like Cron), a CI/CD Pipeline (like GitLab/GitHub Actions), or a Monitoring System?

CI/CD Pipeline runs this using a shell wrapper called main.sh in step 950.

Administration: Is there a "Quality Manager" or "System Admin" who is responsible for adding new .sql files to the /checks directory?

yes Quality Manager adds sql files when he identifies a new possible quality problem.

2. What are the secondary systems involved?
Versio.io: We know the script sends events to the Versio API. Does a user then log into the Versio.io UI to acknowledge or resolve these violations?
yes the Quality Manager logs into his Versio.io account and go to the events sections and see whats new and solves and then press the close button and the event is then closed. untill when this new problem occurs the event stays closed. 

Database: Is the database simply a passive data source, or should we consider the Database Administrator (DBA) an actor if they are the ones who must fix the data based on these reports?
Quality Manager is resposble to solve these problem in the DB


3. Are there different "Levels" of Use Cases?
Management: Should there be a use case for "Managing Quality Check Queries" (adding/deleting SQL files)?
yes Quality Manager can do this when needed

Reporting: Is "Sending Violation Alerts" the only goal, or is there also a "Logging Execution Status" goal (since you have several console.log and console.error statements)?

the Quality Manager also checks if any check had any problem when run by this script.

4. Error Handling and Notifications
Failure: If the database connection fails or the API token is expired, does the script notify a human via Email/Slack, or does it just log the error locally?

5. Environment Configuration
Setup: Who is responsible for managing the environment variables (API tokens, server URLs)? Should "Configure Environment" be a setup-level use case?
---

## 3.2. Entwurf der Datenbank-Anbindung
[Content here]
## 3.3. Ausarbeitung der Versio.io API Rate-Limiting
[Content here]
## 3.4. Entwurf API-Integration & Error-Handling
[Content here]
## 3.5. Erstellung des Pflichtenhefts
[Content here]


# 2. Informationen
## 2.1. Soll/Ist- und Wirtschaftlichkeitsanalyse (Ink. Amortisationsdauer)
[Content here]
## 2.2. Analyse der Pipeline-Struktur und Architektur

```plantuml

@startuml name

title Lifecycle & Vulnerability Data Sources


package "Vulnerability" #fef9e7 {
    rectangle "Security Sources" {
        database "NVD" as nvd
        database "RedHat Security" as rh_sec
        database "GitHub Advisories" as gh_adv
        database "Vendor Advisories\n(Palo Alto, Juniper)" as vendor_adv
    }
}

package "Release & End of Life" #eaf2f8 {
    rectangle "External Feeds" {
        file "XML Data" as xml
        file "JSON Data" as json
        cloud "HTML/Web" as html_cloud
        [GitHub Tags/Releases]
        
        storage "Linux Repos\n(RedHat, Ubuntu)" as linux_repos
        
        package "Package Managers\n(WinGet, Chocolatey)" as pkg_mgrs
    }

    rectangle "Internal Feeds" {
        rectangle "Testing Env. " #fff3e0 {
            [Automation Script] <<WinGet Runner>>
        }
        rectangle "Customer Environment Feed" #e8f5e9 {
            [Versio.io Coverage \n product versions]
        }
    }
}

process "Versio.io Pipeline" <<process>> as pipeline {
    component [106-cve_load-raw-cve-nvd]
    component [110-cve_load-raw-cve-redhat]
    component [120-cve_load-raw-cve-github]
    component [130-cve_load-raw-cve-juniper]
    component [217-productVersions_import_generic]
    component [216-productVersions_import-versions-linux-repo]
    component [CSV List]
    component [950-data-quality-checks]
}

rectangle "Versio.io AI Repository" {
    database "productVersions"
    database "cveRepository"
}

nvd --> [106-cve_load-raw-cve-nvd] : Raw CVE Info.
rh_sec --> [110-cve_load-raw-cve-redhat] : Raw CVE Info.
gh_adv --> [120-cve_load-raw-cve-github]
vendor_adv --> [130-cve_load-raw-cve-juniper] : Raw CVE Info.

' Connectivity - Release & EoL
xml --> [217-productVersions_import_generic]
json --> [217-productVersions_import_generic]
html_cloud --> [217-productVersions_import_generic]
[GitHub Tags/Releases] --> [217-productVersions_import_generic]
linux_repos --> [216-productVersions_import-versions-linux-repo]
pkg_mgrs --> [pipeline]

[Automation Script] --> pipeline : Live Data
[Customer Environment Feed] --> pipeline : Unmapped Versions
[Versio.io AI Repository] --> "950-data-quality-checks": Read DB content
[950-data-quality-checks] --> "Versio.io AI Repository": Write Back to DB
pipeline --> "Versio.io AI Repository" : Store 
@enduml

```

Jeder Pipeline-Schritt folgt einem einheitlichen Aufbau:

```plantuml
@startuml
skinparam monochrome true
skinparam backgroundColor #FEFEFE

title Struktogramm: Standard Schritt

rectangle "pipeline/XXX-schritt-name/" {
  rectangle "main.sh" {
    rectangle "set -e"
    rectangle "parent_path ermitteln"
            rectangle "node main.js aufrufen"
  }
  rectangle "main.js" {
    rectangle "Konfiguration laden"
    rectangle "Datenbankverbindung"
            rectangle "Hauptlogik ausführen"
            rectangle "Ergebnis verarbeiten"
  }
}

@enduml
```



[Content here]
## 2.3. Analyse der API-Schnittstelle und Anforderungen
[Content here]
## 2.4. Festlegung des standardisierten SQL-Formats
[Content here]
## 2.5. Vorbereitung des Projekt-Lastenhefts
[Content here]

<div style="page-break-after: always;"></div>

# 4. Durchführung
## 4.1.–4.13.
[Content here]

<div style="page-break-after: always;"></div>


# 5. Kontrolle & Dokumentation
## 5.1.–5.8.
[Content here]

<div style="page-break-after: always;"></div>


# 6. Fazit
## 6.1. Soll-Ist-Vergleich
[Content here]
## 6.2. Lessons Learned
[Content here]
## 6.3. Ausblick
[Content here]

<div style="page-break-after: always;"></div>


# 7. Literaturverzeichnis
[Sources here]

<div style="page-break-after: always;"></div>


# A. Anhang

## A.1. Lastenheft
### A.1.1. Funktionalitäten
[Content here]
### A.1.2. Technische Anforderungen
[Content here]
### A.1.3. Nicht-funktionale Anforderungen
[Content here]
### A.1.4. Lieferumfang
[Content here]
### A.1.5. Abnahmekriterien
[Content here]

## A.2. Pflichtenheft
### A.2.1. Funktionale Anforderungen
[Content here]
### A.2.2. Nicht-funktionale Anforderungen
[Content here]
### A.2.3. Technische Anforderungen
[Content here]
### A.2.4. Lieferumfang
[Content here]
### A.2.5. Abnahmekriterien
[Content here]

## A.3. Verwendete Ressourcen
[Content here]

## A.4. Middleware
[Content here]

## A.5. Der Grund für die Verwendung von Versio.io Events
[Content here]

## A.6. Der Grund für die Verwendung von sql-datien
[Content here]

## A.7. Fehlercodes und Statuscode-Meldungen
[Content here]

## A.8. Use-Case Diagramm
[Content here]

## A.9. Komponenten Diagramm
[Content here]