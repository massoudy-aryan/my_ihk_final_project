# Entwicklung eines Qualitätsprüfungssystems für den Versio.io Produktlebenszyklus und Schwachstellen-Datenbankcontent
*Abschlussdokumentation Aryan Massoudy IHK-Projekt*


Betreuer von Seiten der Ausbildungsstätte: Matthias Scholze (QMETHODS/Versio.io)

<div style="page-break-after: always;"></div>

## Inhaltsverzeichnis

1. [Einleitung](#1-einleitung)  
   1.1. [Projektbeschreibung](#11-projektbeschreibung)  
   1.2. [Projektziel](#12-projektziel)  
   1.3. [Projektmotivation](#13-projektmotivation)  
   1.4. [Projektbeteiligte](#14-projektbeteiligte)  
   1.5. [Projektabgrenzung](#15-projektabgrenzung)  
   1.6. [Anwendungsfälle](#16-anwendungsfälle)  

2. [Planung](#2-planung)  
   2.1. [Aktivitäts- und Aufwandsplanung](#21-aktivitäts--und-aufwandsplanung)  
   2.2. [Ressourcenplanung](#22-ressourcenplanung)  
   2.3. [Risikoanalyse](#23-risikoanalyse)  

3. [Konzeption](#3-konzeption)  
   3.1. [Erstellung des Pflichtenhefts](#31-erstellung-des-pflichtenhefts)  
   3.2. [Entwurf der UML-Diagramme (Aktivitäts- und Use-Case-Diagramm)](#32-entwurf-der-uml-diagramme-aktivitäts--und-use-case-diagramm)  
   3.3. [Entwurf der Datenbank-Anbindung](#33-entwurf-der-datenbank-anbindung)  
   3.4. [Ausarbeitung des Versio.io API Rate-Limitings](#34-ausarbeitung-des-versioio-api-rate-limitings)  
   3.5. [Entwurf API-Integration & Error-Handling](#35-entwurf-api-integration--error-handling)  
   3.6. [Soll/Ist- und Wirtschaftlichkeitsanalyse (inkl. Amortisationsdauer)](#36-sollist--und-wirtschaftlichkeitsanalyse-inkl-amortisationsdauer)  
   3.7. [Analyse der Pipeline-Struktur und Architektur](#37-analyse-der-pipeline-struktur-und-architektur)  
   3.8. [Analyse der API-Schnittstelle und Anforderungen](#38-analyse-der-api-schnittstelle-und-anforderungen)  
   3.9. [Festlegung des standardisierten SQL-Formats](#39-festlegung-des-standardisierten-sql-formats)  
   3.10. [Vorbereitung des Projekt-Lastenhefts](#310-vorbereitung-des-projekt-lastenhefts)  
   3.11. [Lösungsalternativen](#311-lösungsalternativen)  

4. [Durchführung](#4-durchführung)  
   4.1. [Erstellung der Struktur in der bestehenden Pipeline](#41-erstellung-der-struktur-in-der-bestehenden-pipeline)  
   4.2. [Implementierung der Datenbank-Anbindung](#42-implementierung-der-datenbank-anbindung)  
   4.3. [Entwicklung des SQL-Datei-Scanners](#43-entwicklung-des-sql-datei-scanners)  
   4.4. [Realisierung eines optimierten Prozessors für API-Calls](#44-realisierung-eines-optimierten-prozessors-für-api-calls)  
   4.5. [Sicherstellung des Rate-Limiting-Mechanismus](#45-sicherstellung-des-rate-limiting-mechanismus)  
   4.6. [Implementierung der Logik zur Ergebnisformatierung](#46-implementierung-der-logik-zur-ergebnisformatierung)  
   4.7. [Entwicklung der API-Schnittstelle (PUT/POST-Requests)](#47-entwicklung-der-api-schnittstelle-putpost-requests)  
   4.8. [Implementierung eines robusten Fehlerhandlings (Try-Catch)](#48-implementierung-eines-robusten-fehlerhandlings-try-catch)  
   4.9. [Integration von Logging](#49-integration-von-logging)  
   4.10. [Erstellung des Shell-Skript-Wrappers (main.sh)](#410-erstellung-des-shell-skript-wrappers-mainsh)  
   4.11. [Konfiguration der Umgebungsvariablen & Tokens](#411-konfiguration-der-umgebungsvariablen--tokens)  
   4.12. [Code-Refactoring und Optimierung](#412-code-refactoring-und-optimierung)  
   4.13. [Erstellung von Beispiel-SQL-Queries](#413-erstellung-von-beispiel-sql-queries)  

5. [Qualitätssicherung](#5-qualitätssicherung)  
   5.1. [Code-Review durch das Entwicklungsteam](#51-code-review-durch-das-entwicklungsteam)  
   5.2. [Platzierung in die bestehende Pipeline](#52-platzierung-in-die-bestehende-pipeline)  
   5.3. [Erfolgskontrolle in der Entwicklungsumgebung und Whitebox-Test](#53-erfolgskontrolle-in-der-entwicklungsumgebung-und-whitebox-test)  
   5.4. [Soll-Ist-Vergleich](#54-soll-ist-vergleich)  
   5.5. [Abnahme durch Projektverantwortliche](#55-abnahme-durch-projektverantwortliche)  

6. [Dokumentation](#6-dokumentation)  
   6.1. [Projektdokumentation (prozessorientiert)](#61-projektdokumentation-prozessorientiert)  
   6.2. [Entwicklerdokumentation](#62-entwicklerdokumentation)  
   6.3. [Benutzerhandbuch](#63-benutzerhandbuch)  

7. [Projektabschluss & Fazit](#7-projektabschluss--fazit)  
   7.1. [Soll-Ist-Vergleich](#71-soll-ist-vergleich)  
   7.2. [Lessons Learned](#72-lessons-learned)  
   7.3. [Ausblick](#73-ausblick)  

A. [Anhang](#a-anhang)  
   A.0. [Literaturverzeichnis](#a0-literaturverzeichnis)  
   A.1. [Lastenheft](#a1-lastenheft)  
   A.2. [Pflichtenheft](#a2-pflichtenheft)  
   A.3. [Verwendete Ressourcen](#a3-verwendete-ressourcen)  
   A.4. [Der Grund für die Verwendung von Versio.io Events](#a4-der-grund-für-die-verwendung-von-versioio-events)  
   A.5. [Der Grund für die Verwendung von SQL-Dateien](#a5-der-grund-für-die-verwendung-von-sql-dateien)  
   A.6. [Fehlercodes und Statuscode-Meldungen](#a6-fehlercodes-und-statuscode-meldungen)  

<div style="page-break-after: always;"></div>


## 1. Einleitung
### 1.1. Projektbeschreibung
Versio.io (ein Softwareprodukt der QMETHODS – Business & IT Consulting GmbH) ist eine Plattform, die die gesamte IT-Landschaft eines Unternehmens inventarisiert. Basierend auf dieser digitalen Nachbildung (Digital Twin) werden alle Änderungen erkannt und können im Hinblick auf IT-Governance und Sicherheit bewertet werden. Neben anderen Funktionen bietet Versio.io auch eine Bewertung des Lebenszyklus und der Sicherheit von Software- und Hardwareprodukten.

Im Backend wird eine Pipeline mit mehreren Schritten genutzt. Diese sorgt dafür, die benötigten Daten für unterstützte Software- und Hardwareprodukte aus verschiedenen Online-Quellen zu kollektieren, zu bearbeiten und in der Produktlebenszyklus- und Schwachstellen-Datenbank zu speichern. Nach der Speicherung in der DB, werden die Daten für das Frontend der Versio.io-Plattform bereitgestellt, welches von Kunden genutzt wird, um ihre eigene Software und Hardware auf Aktualität und Schwachstellen zu überprüfen.

Nun soll ich die Pipeline um einen weiteren Schritt erweitern, der SQL-Queries für verschiedene Qualitätskontrollen als Datei importiert, liest und gegen die Versio.io-Datenbankinhalte ausführt. Bei gefundenen Problemen werden diese mithilfe einer API an die Versio.io-Plattform gesendet. Dort werden sie intern von Versio.io QA-Mitarbeitern korrigiert und beim nächsten Durchlauf des Pipeline-Schritts als abgeschlossen gekennzeichnet.

### 1.2. Projektziel
Das primäre Projektziel ist die Implementierung eines weiteren Schrittes in der Backend-Pipeline zur Datenqualitätsprüfung. Dieser soll SQL-Dateien einlesen (welche von QA-Mitarbeitern bei Bedarf geschrieben werden, um Probleme zu erkennen), um eine automatisierte Überwachung und Berichterstattung zu gewährleisten.

Ein zentraler Bestandteil ist die direkte Anbindung an die Versio.io-Plattform via API, wodurch identifizierte Qualitätsprobleme ohne manuelles Eingreifen gemeldet werden. Die Robustheit soll durch Fehlerbehandlung für Datenbank- und Schnittstellenkonflikte sichergestellt werden. Durch die Umsetzung des Projekts soll die manuelle Datenqualitätsprüfung reduziert werden, was zu Zeit- und Kosteneinsparungen führen soll.

Für eine übersichtlichere und einfachere Darstellung des Soll-Konzepts dient das folgende Flussdiagramm:
Die Schritte 1, 2 und 3 sollen implementiert werden. Schritt 4 (Versio.io), der die Daten aus dem neuen Pipeline-Schritt empfängt und weiterverarbeitet, ist breit vorhanden.

### 1.3. Projektmotivation
Die Versio.io-Plattform funktioniert nur so gut wie die Qualität der Daten, auf denen sie basiert. Da Kunden ihre Entscheidungen auf diesen Informationen zu Lebenszyklus und Schwachstellen treffen, ist es wichtig, dass die Daten zuverlässig und korrekt sind. Bisher hat das Backend-Team die Qualitätssicherung vor allem durch manuelle Stichproben und zufällige SQL-Abfragen gemacht. Dieser Prozess war aus drei Gründen begrenzt:
   * Bei der schnell steigenden Anzahl von Softwareprodukte in den End-of-Life- und Schwachstellen-Datenbanken war es einfach nicht zu schaffen, alle Daten manuell zu prüfen. Die Skalierbarkeit und die knappe Zeit haben das unmöglich gemacht. Eine komplette Qualitätskontrolle war deswegen wirtschaftlich kaum machbar.
   * Latenzprobleme treten oft auf, wenn es Inkonsistenzen gibt, zum Beispiel fehlende Wartungsdaten in der neuesten Version, wie im SQL-Beispiel gezeigt. Solche Probleme werden meistens erst entdeckt, nachdem sie schon in der Versio.io-Versionsvisualisierung war sichtbar. Das hat das Vertrauen in die Gültigkeit der von Versio.io negativ beeinträchtigt.
   * Die Automatisierung fehlte, sodass es zu lange dauerte, bis ein Fehler, der bei manuellen Datenbankprüfungen entdeckt wurde, an einen QA-Mitarbeiter weitergeleitet wurde.Man konnte eine SQL-Fehlermeldung nicht automatisch in ein Event auf der Plattform umwandeln, das man dann nachverfolgen konnte. 

Der Hauptgrund für dieses Projekt ist, genau diese Lücke zu schließen. Ich will ein System einführen, das Fehler nicht nur erkennt, sondern sie auch von sich aus meldet.Indem die Validierungslogik in die vorhandene Pipeline bei Schritt 950 eingebaut wird, können die Ergebnisse direkt an das Versio.io weitergeleitet werden. Mit dem Schritt mache ich aus einer passiven Datenbankabfrage einen aktiven Überwachungsprozess.

### 1.4. Projektbeteiligte

Um die risikio das false-entwicklung und Integration des neuen Pipeline-Schritts in die bestehende Infrastruktur zu gewährleisten, erfolgt die Umsetzung in enger Abstimmung mit den verantwortlichen Fachbereichen der QMETHODS / Versio.io.

Die folgenden Personen waren im Projektablauf beteiligt:

* **Aryan Massoudy (Projektleiter & Entwickler):**
Verantwortlich für die Konzeption, die technische Implementierung der Node.js-Logik, das API-Mapping sowie die finale Qualitätssicherung und Dokumentation des Projekts.
* **Matthias Scholze (Projektbetreuer / Mentor):**
Fungiert als technischer Ansprechpartner und Mentor seitens der Ausbildungsstätte. Er unterstützt bei architektonischen Entscheidungen und führt die abschließende Abnahme des Pipeline-Moduls durch.
* **Versio.io Entwicklungsteam (Stakeholder):**
Das Backend-Team stellt die Entwicklungsumgebung und die bestehenden Code-Utilities (z. B. Database-Helper) bereit. Sie unterstützen im Rahmen von Code-Reviews (siehe Kapitel 5.1), um die Wartbarkeit des neuen Moduls sicherzustellen.
* **Versio.io QA-Team (Endanwender):**
Als interne Nutzer definieren sie die Anforderungen an die Fehlerberichte. Sie sind dafür verantwortlich, die durch das Tool erzeugten Events auf der Plattform zu sichten und die Datenkorrekturen in der Datenbank vorzunehmen.

### 1.5. Projektabgrenzung
### 1.6. Anwendungsfälle

<div style="page-break-after: always;"></div>

## 2. Planung
### 2.1. Aktivitäts- und Aufwandsplanung
### 2.2. Ressourcenplanung
### 2.3. Risikoanalyse

<div style="page-break-after: always;"></div>

## 3. Konzeption
### 3.1. Erstellung des Pflichtenhefts
### 3.2. Entwurf der UML-Diagramme (Aktivitäts- und Use-Case-Diagramm)

```plantuml
@startuml
autonumber
skinparam Style strictuml

participant "runQualityChecks()" as Script
entity "File System" as FS
database "Database" as DB
participant "Versio API" as API

Script -> FS: readdir('./checks')
FS --> Script: sqlFiles[]

loop for each fileName in sqlFiles
    Script -> FS: readFile(filePath)
    FS --> Script: sqlQuery
    
    Script -> DB: query(sqlQuery)
    DB --> Script: rows[]
    
    loop for each row in rows
        alt row.violation === 1
            Script -> Script: Format eventJSON
            Script -> API: axios.post(url, eventJSON)
            API --> Script: 200 OK / Response
        else no violation
            note right: Skip row
        end
    end
end

Script -> DB: connectionPool.end()
@enduml
```
*Abbildung: Sequence Diagram*


---
```plantuml

@startuml
start
:Read 'checks' directory;
:Filter for .sql files;

while (More files?) is (yes)
  :Read SQL content;
  :Execute Query on DB;
  
  while (More rows?) is (yes)
    if (row.violation == 1?) then (yes)
      :Construct eventJSON;
      partition "API Call" {
        if (POST to Versio API) then (success)
          :Log Success;
        else (failure/error)
          :Log Error;
        endif
      }
    else (no)
    endif
  endwhile
endwhile

:Close DB Connection;
stop
@enduml

```
*Abbildung: Aktivitätsdiagram*

---

```plantuml
@startuml
' Standardmäßig oben-nach-unten (Portrait)
skinparam packageStyle rectangle
skinparam actorStyle awesome

' Primärer Auslöser oben
actor "CI/CD Pipeline\nSchrite 950\n(main.sh)" as Trigger << System >>

rectangle "Schrite 950" {
  usecase "SQL-Prüfdateien identifizieren" as UC1
  usecase "SQL-Abfragen ausführen" as UC2
  usecase "Daten auf Verletzungen prüfen" as UC3
  usecase "Events an Versio.io senden" as UC4
  usecase "Ausführung protokollieren" as UC5
}

' Externe Systeme unten gruppiert
actor "Dateisystem" as FS << System >>
actor "Datenbank" as DB << System >>
actor "Versio.io API" as API << System >>

' Verbindungen (Vertikale Ausrichtung)
Trigger -- UC1 : Startet Skript
UC1 -- FS : Durchsucht Verzeichnis

Trigger -- UC2 : Steuert Ablauf
UC2 -- DB : Führt Queries aus

UC2 <.. UC3 : <<include>>\n(Verarbeitet Zeilen)
UC3 <.. UC4 : <<extend>>\n(Nur bei violation == 1)

UC4 -- API : Sendet JSON

Trigger -- UC5 : Erfasst Logs
@enduml
```
*Abbildung: Anwendungsfalldiagram*

---



### 3.3. Entwurf der Datenbank-Anbindung
### 3.4. Ausarbeitung des Versio.io API Rate-Limitings
### 3.5. Entwurf API-Integration & Error-Handling
### 3.6. Soll/Ist- und Wirtschaftlichkeitsanalyse (inkl. Amortisationsdauer)
### 3.7. Analyse der Pipeline-Struktur und Architektur
### 3.8. Analyse der API-Schnittstelle und Anforderungen
### 3.9. Festlegung des standardisierten SQL-Formats
### 3.10. Vorbereitung des Projekt-Lastenhefts
### 3.11. Lösungsalternativen

<div style="page-break-after: always;"></div>

## 4. Durchführung
### 4.1. Erstellung der Struktur in der bestehenden Pipeline
### 4.2. Implementierung der Datenbank-Anbindung
### 4.3. Entwicklung des SQL-Datei-Scanners
### 4.4. Realisierung eines optimierten Prozessors für API-Calls
### 4.5. Sicherstellung des Rate-Limiting-Mechanismus
### 4.6. Implementierung der Logik zur Ergebnisformatierung
### 4.7. Entwicklung der API-Schnittstelle (PUT/POST-Requests)
### 4.8. Implementierung eines robusten Fehlerhandlings (Try-Catch)
### 4.9. Integration von Logging
### 4.10. Erstellung des Shell-Skript-Wrappers (main.sh)
### 4.11. Konfiguration der Umgebungsvariablen & Tokens
### 4.12. Code-Refactoring und Optimierung
### 4.13. Erstellung von Beispiel-SQL-Queries

<div style="page-break-after: always;"></div>


## 5. Qualitätssicherung
### 5.1. Code-Review durch das Entwicklungsteam
### 5.2. Platzierung in die bestehende Pipeline
### 5.3. Erfolgskontrolle in der Entwicklungsumgebung und Whitebox-Test
### 5.4. Soll-Ist-Vergleich
### 5.5. Abnahme durch Projektverantwortliche

<div style="page-break-after: always;"></div>


## 6. Dokumentation
### 6.1. Projektdokumentation (prozessorientiert)
### 6.2. Entwicklerdokumentation
### 6.3. Benutzerhandbuch

<div style="page-break-after: always;"></div>


## 7. Projektabschluss & Fazit
### 7.1. Soll-Ist-Vergleich
### 7.2. Lessons Learned
### 7.3. Ausblick

<div style="page-break-after: always;"></div>


## A. Anhang
### A.0. Literaturverzeichnis
### A.1. Lastenheft
### A.2. Pflichtenheft
### A.3. Verwendete Ressourcen
### A.4. Der Grund für die Verwendung von Versio.io Events
### A.5. Der Grund für die Verwendung von SQL-Dateien
### A.6. Fehlercodes und Statuscode-Meldungen